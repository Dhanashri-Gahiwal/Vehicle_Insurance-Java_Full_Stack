package com.edu.vehicle.repository;

import java.sql.Date;
import java.util.List;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.edu.vehicle.entity.Vehicle;


@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
	
	
	@Query("FROM Vehicle WHERE vehicleName like :vehicleName  ")
	List<Vehicle> findByName(String vehicleName);

	
	@Query(value="select * from Vehicle where insurancedate between ?1 AND ?2 ",nativeQuery = true)
	List<Vehicle> findvehiclebetweentwodate(Date insuranceStartDate, Date insuranceEndDate);	
     
}