package com.edu.vehicle.service;

import java.util.List;


import javax.validation.Valid;

import com.edu.vehicle.entity.Customer;
import com.edu.vehicle.error.GlobalExceptionHandling;

public interface CustomerService {

	public Customer addCustomer(@Valid Customer customer);

	public Customer getCustomerById(Long customerId) throws GlobalExceptionHandling;

	public Customer updateCustomerById(@Valid Long customerId, Customer customer) throws GlobalExceptionHandling;

	public Customer deleteCustomerById(Long customerId) throws GlobalExceptionHandling;

	public List<Customer> findAllCustomer();

	public Customer customerAssignVehicle(Long customerId, Long insuranceId);

	public List<Customer> findcustomerByName(String customerName);

}
