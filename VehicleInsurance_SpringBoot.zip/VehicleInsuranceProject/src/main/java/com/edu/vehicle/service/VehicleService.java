package com.edu.vehicle.service;

import java.sql.Date;

import java.util.List;
import com.edu.vehicle.entity.Vehicle;
import com.edu.vehicle.error.GlobalExceptionHandling;

public interface VehicleService {

	public Vehicle addvehicle(Vehicle vehicle);

	public Vehicle getVehicleById(Long insuranceId)throws GlobalExceptionHandling;

	public Vehicle deletevehicleById(Long insuranceId) throws GlobalExceptionHandling;

    public Vehicle UpdatevehicleById(Long insuranceId, Vehicle vehicle) throws GlobalExceptionHandling;

	public List<Vehicle> getAllVehicles();

	public List<Vehicle> findvehicleByName(String vehicleName);

	public List<Vehicle> findvehiclebetweentwodate(Date insuranceStartDate, Date insuranceEndDate);

	

	

}