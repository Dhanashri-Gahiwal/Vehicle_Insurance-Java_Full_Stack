package com.edu.vehicle.service;

import java.util.ArrayList;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.vehicle.entity.Customer;
import com.edu.vehicle.entity.Vehicle;
import com.edu.vehicle.error.GlobalExceptionHandling;
import com.edu.vehicle.repository.CustomerRepository;
import com.edu.vehicle.repository.VehicleRepository;

@Service
public class CustomerServiceImp implements CustomerService{
    @Autowired
	private CustomerRepository customerRepository;
    
    @Autowired
    private VehicleRepository vehicleRepository;
    
	@Override
	public Customer addCustomer(Customer customer) {		
		Customer customerSaved = customerRepository.save(customer);
		return customerSaved;
	}
	
	@Override
	public Customer getCustomerById(Long customerId) throws GlobalExceptionHandling{		
		Optional<Customer> cus=customerRepository.findById(customerId);
		if(!cus.isPresent()) {
			throw new GlobalExceptionHandling("Customer Not Found");
		}
		Customer cst=customerRepository.findById(customerId).get();		
		List <Customer>l=new ArrayList<>();
		l.add(cst);
		return customerRepository.findById(customerId).get();
	}

	@Override
	public Customer updateCustomerById(Long customerId, Customer customer) throws GlobalExceptionHandling {
		//get the record from the table
		
		Optional<Customer> vle=customerRepository.findById(customerId) ;
		Customer vleDB=null;
		if(!vle.isPresent()) {
			 throw new GlobalExceptionHandling("Customer Not Found");
		}
		
	 else{
			vleDB =customerRepository.findById(customerId).get();
				
				if(Objects.nonNull(customer.getCustomerName()) &&
				!"".equalsIgnoreCase(customer.getCustomerName())) {
					vleDB.setCustomerName(customer.getCustomerName());
				}
				if(Objects.nonNull(customer.getCustomerAdharno()) ) {
					vleDB.setCustomerAdharno(customer.getCustomerAdharno());
				}
				
				if(Objects.nonNull(customer.getCustomerPanno()) &&
						!"".equalsIgnoreCase(customer.getCustomerPanno())) {
							vleDB.setCustomerPanno(customer.getCustomerPanno());
						}
				if(Objects.nonNull(customer.getCustomerPhone())) {
					vleDB.setCustomerPhone(customer.getCustomerPhone());
				}
				
				if(Objects.nonNull(customer.getCustomerDrivinglisenceno()) &&
				!"".equalsIgnoreCase(customer.getCustomerDrivinglisenceno())) {
					vleDB.setCustomerDrivinglisenceno(customer.getCustomerDrivinglisenceno());
				}
				
			}//else
		return customerRepository.save(vleDB);
	}
	
	@Override
	public Customer deleteCustomerById(Long customerId) throws GlobalExceptionHandling {
		Optional<Customer> cus=customerRepository.findById(customerId);		
		if(!cus.isPresent()) {
			throw new GlobalExceptionHandling("Customer Id Not present");
		}
		customerRepository.deleteById(customerId);
		return (Customer) customerRepository.findAll(); 
		
		}
	
	
	@Override
	public Customer customerAssignVehicle(Long CustomerId, Long insuranceId) {	
		Vehicle vehicle=vehicleRepository.findById(insuranceId).get();
		Customer customer=customerRepository.findById(CustomerId).get();
		System.out.println("customerAssignVehicle "+vehicle);
		System.out.println("customerAssignVehicle "+customer);
		
		customer.customerAssignVehicle(vehicle);
		return customerRepository.save(customer);
	}
	
	@Override
	public List<Customer> findAllCustomer() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}

	public List<Customer> findcustomerByName(String customerName) {
		// TODO Auto-generated method stub
		return customerRepository.findByName(customerName) ;
	}
	
}
