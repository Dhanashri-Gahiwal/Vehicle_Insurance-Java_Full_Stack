import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HardcodedAuthenticationService {

  constructor() { }
  authenticate(username:string,password:string){
    //console.log('before authentication')
    if(username==='dhanashri' && password==='dhanashri123'){
      sessionStorage.setItem('authenticateuser',username); //store user name in session
      //console.log('after authentication')
      return true;
    }else{
      return false;
    }


  }
  isUserLoggedin(){
    let user=sessionStorage.getItem('authenticateuser')
    return !(user===null)
  }

  logout(){
    sessionStorage.removeItem('authenticateuser');
  }
}
