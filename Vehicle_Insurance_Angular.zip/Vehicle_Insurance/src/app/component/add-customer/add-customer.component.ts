import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer/customer.component';
import { ActivatedRoute, Router } from '@angular/router';
import { InsuranceDataService } from 'src/app/service/data/insurance-data.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit{

  customerId:number;
  addCustomer:Customer;
  insuranceId: number;

  constructor(
    private insuranceService: InsuranceDataService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.customerId = this.route.snapshot.params['customerId']; //read from url
    //avoid errors
    this.addCustomer = new Customer(
      this.customerId,
      '',
      0,
      '',
      0,
      '',
      this.insuranceId
    );

    //if id!=-1 then only get the record
    if(this.customerId!=-1){
    console.log(this.customerId); //initially on form load get the data (first)
    this.insuranceService
      .retriveCustomer(this.customerId)
      .subscribe((data) => (this.addCustomer = data));
  }
}

  saveCustomer() {
    //for update and save based on id of URL if id=-1 add record else update
    if (this.customerId == -1) {
      //add record
  
            this.insuranceService.addCustomer(this.addCustomer).subscribe(
        (data) => this.router.navigate(['customer']) //navigate to customers page
      );
    }
    //update record
    else {
      this.insuranceService
        .updateCustomer(this.customerId, this.addCustomer)
        .subscribe((data) => {
          console.log(data);
          //after update navigate to addCustomer component ,inject an object of addCustomer
          this.router.navigate(['customer']);
        });
    }
  }

}
