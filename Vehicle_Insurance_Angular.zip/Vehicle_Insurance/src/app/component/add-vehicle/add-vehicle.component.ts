import { Component, OnInit } from '@angular/core';
import { Vehicle } from '../vehicleInsurance/vehicle-insurance.component';
import { InsuranceDataService } from 'src/app/service/data/insurance-data.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-vehicle',
  templateUrl: './add-vehicle.component.html',
  styleUrls: ['./add-vehicle.component.css'],
})
export class AddVehicleComponent implements OnInit {
  insuranceId: number;
  addVehicle: Vehicle;

  constructor(
    private insuranceService: InsuranceDataService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.insuranceId = this.route.snapshot.params['insuranceId']; //read from url
    //avoid errors
    this.addVehicle = new Vehicle(
      this.insuranceId,
      '',
      '',
      '',
      0,
      new Date(),
      new Date()
    );
    //if id!=-1 then only get the record

    if(this.insuranceId!=-1){
    console.log(this.insuranceId); //initially on form load get the data (first)
    this.insuranceService
      .retriveInsurance(this.insuranceId)
      .subscribe((data) => (this.addVehicle = data));
    }
  }

  saveInsurance() {
    //for update and save based on id of URL if id=-1 add record else update
    if (this.insuranceId == -1) {
      //add record
      this.insuranceService.addInsurance(this.addVehicle).subscribe(
        (data) => this.router.navigate(['vehicle-insurance']) //navigate to vehicleInsurance page
      );
    }
    //update record
    else {
      this.insuranceService
        .updateInsurance(this.insuranceId, this.addVehicle)
        .subscribe((data) => {
          console.log(data);
          //after update navigate to addVehicle component ,inject an object of addVehicle
          this.router.navigate(['vehicle-insurance']);
        });
    }
  }
}
