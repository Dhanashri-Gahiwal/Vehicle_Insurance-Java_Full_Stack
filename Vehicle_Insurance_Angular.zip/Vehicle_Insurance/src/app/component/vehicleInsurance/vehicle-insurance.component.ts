import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InsuranceDataService } from 'src/app/service/data/insurance-data.service';

@Component({
  selector: 'app-vehicle-insurance',
  templateUrl: './vehicle-insurance.component.html',
  styleUrls: ['./vehicle-insurance.component.css']
})
export class VehicleInsuranceComponent implements OnInit{
//to connect backend
  vehicleInsurance: Vehicle[] = []; // array of object

  //Inject object of InsuranceService
constructor(private insuranceService:InsuranceDataService,private router:Router) {}
  ngOnInit(): void {
    this.refreshInsurance();
  }

  refreshInsurance(){
    this.insuranceService.retrieveAllInsurance().subscribe(
      response=>{
        console.log(response);
        this.vehicleInsurance=response;
      }
    )
  }

  //Delete
  deleteInsurance(insuranceId:number){
    console.log(`deleteInsurance  id=${insuranceId}`)
    //call deleteInsurance from service
    this.insuranceService.deleteInsurance(insuranceId).subscribe(
     response=>{
       this.refreshInsurance();
     }
    )
}

updateInsurance(insuranceId:number){
  console.log(`update record id=${insuranceId}`);

  this.router.navigate(['addVehicle',insuranceId]);
 }

  addInsurance(){
    console.log("add Insurance")
    this.router.navigate(['addVehicle',-1]); //navigate with -1 to add
    }

}

export class Vehicle{  //user defined typescript class
 
    constructor(public insuranceId:number,
      public vehicleNo:string,
      public vehicleColour:string,
      public vehicleName:string,
      public vehiclePrice:number,
      public insuranceStartDate:Date,
      public insuranceEndDate:Date
        ) {}
}
